@extends('layouts.default')

@section('content')

<h1>Teams</h1>

@foreach ($teams as $team)
    
<ul>
    <li><a href="/{{$team->id}}">{{$team->id}}</a></li>
    <li>{{$team->name}}</li>
    <li>{{$team->email}}</li>

</ul>
@endforeach
@endsection