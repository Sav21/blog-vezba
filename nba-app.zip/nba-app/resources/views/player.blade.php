@extends('layouts.default')

@section('content')


<h1>Player info</h1>

<ul>
    <li>{{$player->first_name}}</li>
    <li>{{$player->last_name}}</li>
    <li>{{$player->email}}</li>
    <li>{{$player->team->name}}</li>
</ul>

@endsection