@extends('layouts.default')

@section('content')

<h1>{{$team->name}}</h1>

<ul>
    <li>{{$team->email}}</li>
    <li>{{$team->address}}</li>
    <li>{{$team->city}}</li>

</ul>
<h4>Players:</h4>

@foreach ($team->players as $player)
    <ul>
        <li><a href="/player/{{$player->id}}">{{$player->id}}</a></li>
        <li>{{$player->first_name}}</li>
    </ul>
    
@endforeach

<form action="{{url('/createcomment')}}" method="POST" class="mt-5">
    @csrf
    <div class="mb-3">
        <label class="form-label">Enter your comment</label>
        <textarea type="text" class="form-control" name="body" required></textarea>
        <input type="hidden" name="team_id" value="{{ $team->id }}">
    </div>
    <button type="submit" class="btn btn-primary">Post Comment</button>
</form>
@include('layouts.errors')
@include('layouts.session')
@include('components.comment')
@endsection