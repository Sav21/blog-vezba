<?php

namespace App\Http\Controllers;

use App\Mail\VerificationMail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;


class AuthController extends Controller
{
    public function getSignIn() {
        return view('auth.signin');
    }
    public function getSignUp(){
        return view('auth.signup');
    }

    public function signUp(Request $request) {
        if(Auth::check()) {
            return redirect('/signup')->withErrors('You are already signed in!');
        }

        $request->validate([
            'name' => 'required|min:2|max:255|string',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|confirmed|min:3|max:255|string|confirmed',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ]);
        
        $mailData = $user->only('id');
        Mail::to($user->email)->send(new VerificationMail($mailData));

        return redirect('/signin')->with('status', 'You have signed up!');
    }

    public function signIn(Request $request) {
        if(Auth::check()) {
            return redirect('/signin')->withErrors('You are already signed in!');
        }

        $request->validate([
            'email' => 'required|exists:users,email',
            'password' => 'required'
        ]);

        $credentials = $request->only('email', 'password');
        if(Auth::attempt($credentials)) {
            return redirect()->intended('/')->with('status', 'Sign in');
        }

        return redirect('/')->withErrors('Invalid credentials');
    }
    public function signOut() {
        Session::flush();
        Auth::logout();

        return Redirect('signin');
    }
}
