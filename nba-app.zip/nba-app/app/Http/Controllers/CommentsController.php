<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Team;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        
        if(!Auth::check()) {
            return redirect('/' . $request->team_id)->withErrors('Only authenticated user can post comments');
        }

        $request->validate([
            'body' => 'required|min:10|max:2000|string',
            'team_id' => 'required|exists:teams,id'
        ]);

        $team = Team::find($request->team_id);
        
        $user = User::find(Auth::user()->id);

        
        $comment = new Comment();
        $comment->body = $request->body;
        $comment->team()->associate($team);
        $comment->user()->associate($user);
        $comment->save();

        return redirect('/' . $request->team_id)->with('status', 'Comment successfully created!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
