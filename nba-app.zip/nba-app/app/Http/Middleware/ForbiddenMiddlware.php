<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ForbiddenMiddlware
{
    public $words = ['hate', 'idiot', 'stupid'];
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        foreach ($this->words as $word) {
           if(strstr($request->body, $word)) {
            return redirect('/' . $request->team_id)->withErrors('forbiden words');
           }
        }
        return $next($request);
    }
}
