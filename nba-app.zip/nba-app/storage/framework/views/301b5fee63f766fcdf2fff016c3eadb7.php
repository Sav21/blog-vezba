<?php $__env->startSection('content'); ?>


<h1>Player info</h1>

<ul>
    <li><?php echo e($player->first_name); ?></li>
    <li><?php echo e($player->last_name); ?></li>
    <li><?php echo e($player->email); ?></li>
    <li><?php echo e($player->team->name); ?></li>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/player.blade.php ENDPATH**/ ?>