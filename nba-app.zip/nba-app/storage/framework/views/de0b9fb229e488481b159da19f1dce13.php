<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    Click <a href="http://localhost:8001/verify/<?php echo e($mailData['id']); ?>">here</a> to verify
    
</body>
</html><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/mails/verification.blade.php ENDPATH**/ ?>