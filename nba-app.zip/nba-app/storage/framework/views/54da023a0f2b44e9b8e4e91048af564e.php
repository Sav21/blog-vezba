<?php $__env->startSection('content'); ?>

<h1>Teams</h1>

<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<ul>
    <li><a href="/<?php echo e($team->id); ?>"><?php echo e($team->id); ?></a></li>
    <li><?php echo e($team->name); ?></li>
    <li><?php echo e($team->email); ?></li>

</ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/teams.blade.php ENDPATH**/ ?>