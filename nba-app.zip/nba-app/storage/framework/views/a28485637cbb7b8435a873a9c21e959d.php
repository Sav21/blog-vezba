<?php $__currentLoopData = $team->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container border mt-5">
        <h4><?php echo e($comment->user->name); ?></h4>
        <textarea disabled rows="3" cols="10" style="width: 100%"><?php echo e($comment->body); ?></textarea>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/components/comment.blade.php ENDPATH**/ ?>