@extends('layout.default')


@section('content')

<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
  
    <table>
        <tr>
            <th>Users</th>
            <th>Id</th>
            <th>Delete</th>
        </tr>
        
        @foreach ($users as $user)
        @if (auth()->user()->id !== $user->id)
        <tr>
            <td>{{$user->name}}</td>
            <td>{{$user->id}}</td>
            {{-- <td><form action="{{ url('/deleteUser') }}" method="POST">
            @csrf
            <input type="hidden" value="{{$user->id}}" name ="id">
            <button></button>
        </form>
        </td> --}}
            <td><a href="/users/{{$user->id}}">Delete</a></td>
        </tr>
        @endif
        @endforeach
      </table>
  
  </div>

  {{$users}}

@endsection

@include('layout.session')
@include('layout.errors')