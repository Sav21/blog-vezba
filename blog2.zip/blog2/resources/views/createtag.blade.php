@extends('layout.default')


@section('content')

<form action="{{ url('create') }}" method="POST">
  @csrf
  <div class="mb-3">
    <label class="form-label">Tag</label>
    <textarea type="text" name="name" class="form-control" required></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Create Post</button>

</form>


@include('layout.errors')
@include('layout.session')

@endsection