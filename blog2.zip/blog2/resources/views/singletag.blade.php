@extends('layout.default')
@section('content')

<h1>{{$tag->name}}</h1>

@endsection
