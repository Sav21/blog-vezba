@extends('layout.default')

@section('title')Posts @endsection

@section('content')


<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
  
  @foreach ($tags as $tag)
    <ul>
        <a href="/tags/{{$tag->id}}"><li>{{$tag->id}}</li></a>
        <li>{{$tag->name}}</li>
    </ul>
  @endforeach

</div>


{{$tags}}

@endsection