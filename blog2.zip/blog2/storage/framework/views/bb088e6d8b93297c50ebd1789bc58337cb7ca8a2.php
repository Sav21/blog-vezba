<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
    
       <img src="<?php echo e($mailData["image_url"]); ?>" alt="postimage">
        <h1><?php echo e($mailData["title"]); ?></h1>
        <p><?php echo e($mailData["body"]); ?></p>
</body>
</html><?php /**PATH /Users/vivify/Desktop/treci-cas/blog2/resources/views/mails/createpost.blade.php ENDPATH**/ ?>