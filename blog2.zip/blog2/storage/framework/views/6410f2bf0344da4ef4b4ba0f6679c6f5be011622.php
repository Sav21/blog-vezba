<?php $__env->startSection('content'); ?>
    <div class="container text-align ">
        <h1 class="mt-2"><?php echo e($post->title); ?></h1>
        
        <img class="mt-5" src="<?php echo e($post->image_url); ?>" alt="PostImage">
        <p class="mt-5"><?php echo e($post->body); ?></p>
        <ul>
            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($tag->name); ?></li>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <form action="createcomment" method="POST" class="mt-5">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Enter your comment</label>
            <textarea type="text" class="form-control" name="body" required></textarea>
            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Post Comment</button>
    </form>

    <?php echo $__env->make('layout.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layout.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/blog2/resources/views/singlepost.blade.php ENDPATH**/ ?>