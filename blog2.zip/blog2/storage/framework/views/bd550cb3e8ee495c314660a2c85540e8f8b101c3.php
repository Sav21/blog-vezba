<div class="col">
  <div class="card shadow-sm">
    <img src="<?php echo e($post->image_url); ?>" alt="PostImage">
    <div class="card-body">
      <p class="card-text"><?php echo e($post->body); ?></p>
      <div class="d-flex justify-content-between align-items-center">
        <div class="btn-group">
          
          <a href="/<?php echo e($post->id); ?>" class="btn btn-sm btn-outline-secondary">View</a>
          <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
        </div>
        <small class="text-body-secondary"><?php echo e($post->created_at->diffForHumans()); ?></small>
      </div>
    </div>
  </div>
</div><?php /**PATH /Users/vivify/Desktop/treci-cas/blog2/resources/views/components/post.blade.php ENDPATH**/ ?>