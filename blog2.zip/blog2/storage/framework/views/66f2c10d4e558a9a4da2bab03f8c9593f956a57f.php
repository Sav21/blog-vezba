<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('create')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label">Title</label>
    <input type="text" class="form-control" name="title" required />
  </div>
  <div class="mb-3">
    <label class="form-label">Body</label>
    <textarea type="text" name="body" class="form-control" required></textarea>
  </div>
</div>
<div class="mb-3">
  <label class="form-label">Tags</label>
  <select name="tags[]" multiple class="form-select">
    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>
  <div class="mb-3">
    <label class="form-label">Image Url</label>
    <input type="text" class="form-control" name="image_url" required />
  </div>
  <button type="submit" class="btn btn-primary">Create Post</button>
</form>


<?php echo $__env->make('layout.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/blog2/resources/views/createpost.blade.php ENDPATH**/ ?>