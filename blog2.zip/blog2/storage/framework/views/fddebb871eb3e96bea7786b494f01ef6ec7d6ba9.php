<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
    
        <h1><?php echo e($mailData["name"]); ?></h1>

</body>
</html><?php /**PATH /Users/vivify/Desktop/treci-cas/blog2/resources/views/mails/createtag.blade.php ENDPATH**/ ?>