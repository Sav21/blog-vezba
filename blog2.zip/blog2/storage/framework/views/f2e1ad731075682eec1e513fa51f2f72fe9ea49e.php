<?php if(session('status')): ?>
    <div class="alert alert-success">
      <?php echo e(session('status')); ?>

    </div>
<?php endif; ?><?php /**PATH /Users/vivify/Desktop/treci-cas/blog2/resources/views/layout/session.blade.php ENDPATH**/ ?>