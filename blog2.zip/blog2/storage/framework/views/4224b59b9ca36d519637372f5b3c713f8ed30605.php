<?php $__env->startSection('content'); ?>

<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
  
    <table>
        <tr>
            <th>Users</th>
            <th>Id</th>
            <th>Delete</th>
        </tr>
        
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(auth()->user()->id !== $user->id): ?>
        <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->id); ?></td>
            
            <td><a href="/users/<?php echo e($user->id); ?>">Delete</a></td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
  
  </div>

  <?php echo e($users); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/blog2/resources/views/users.blade.php ENDPATH**/ ?>