<?php $__env->startSection('content'); ?>

<h1><?php echo e($tag->name); ?></h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/blog2/resources/views/singletag.blade.php ENDPATH**/ ?>